/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uam.eps.bmi.search.vsm;

import es.uam.eps.bmi.search.AbstractEngine;
import es.uam.eps.bmi.search.index.Index;
import es.uam.eps.bmi.search.index.lucene.LuceneIndex;
import es.uam.eps.bmi.search.ranking.SearchRanking;
import es.uam.eps.bmi.search.ranking.impl.ModeloVectorialImpl;
import es.uam.eps.bmi.search.ranking.impl.SearchRankingImpl;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sergio
 */
public class VSMEngine extends AbstractEngine{
    public List<ModeloVectorialImpl> vectores;
    
    public VSMEngine(Index idx) throws IOException {
        super(idx);
        vectores=new ArrayList<>();
    }

    @Override
    public SearchRanking search(String query, int cutoff) throws IOException{
        vectores = new ArrayList<>();
        int numDocs = ((LuceneIndex)index).getIndex().numDocs();
        String[] querySplit =  query.toLowerCase().split(" ");
        
        for(int i=0; i< numDocs; i++){
            ModeloVectorialImpl modVec = new ModeloVectorialImpl(i, numDocs);
            for(String queryAux:querySplit){
                modVec.addToIndex(index.getTermFreq(queryAux, i),index.getDocFreq(queryAux));
            }
            vectores.add(modVec);
        }
        
        return new SearchRankingImpl(this.index,vectores);
    }
}
