package es.uam.eps.bmi.search.ranking;

/**
 *
 * @author pablo
 */
public interface SearchRanking extends Iterable<SearchRankingDoc> {
    public int size();
}
