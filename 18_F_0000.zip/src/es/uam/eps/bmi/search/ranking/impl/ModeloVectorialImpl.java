/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uam.eps.bmi.search.ranking.impl;

import java.util.ArrayList;
import java.util.List;
import static org.apache.lucene.search.similarities.SimilarityBase.log2;

/**
 *
 * @author sergio
 */
public class ModeloVectorialImpl {
    public int documentID;
    public int numDocuments;
    public List<Double> scores;
    
    public ModeloVectorialImpl(int dID, int nDoc){
        this.documentID= dID;
        this.numDocuments= nDoc;
        scores= new ArrayList<>();
    }
    
    public double tf(double freq){
        if(freq > 0){
            return (1+log2(freq));
        }
        else{
            return 0;
        }
    }
    
    public double idf(double freq){ 
        return  (log2(this.numDocuments/(freq)));
    }

    public void addToIndex(long termFreq, long docFreq) {
        double tf=this.tf(termFreq);
        double idf=this.idf(docFreq);
        scores.add(tf*idf);
    }
}   
