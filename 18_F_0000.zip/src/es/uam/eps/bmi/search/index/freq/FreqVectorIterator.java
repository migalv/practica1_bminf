package es.uam.eps.bmi.search.index.freq;

import java.util.Iterator;

/**
 *
 * @author pablo
 */
public interface FreqVectorIterator extends Iterator<TermFreq> {
    
}
